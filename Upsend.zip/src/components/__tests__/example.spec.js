/* eslint-disable */

test('example', () => {
  expect(1 + 2).toBe(3);
});

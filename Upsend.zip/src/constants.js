import React from 'react';

//API URL
export const API_URL = 'https://chat-upsend.herokuapp.com/';

//API End Points
export const REGISTER = `${API_URL}/agents.json`;
export const LOGIN = `${API_URL}/agents/sign_in.json`;
export const UPDATE_PROFILE = `${API_URL}/user`;
export const UPLOAD_IMAGE = `${API_URL}/user/upload`;
export const FORGOT_PASSWORD = `${API_URL}/auth/recover`;
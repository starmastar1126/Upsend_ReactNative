import { connect } from 'react-redux';
import { compose } from 'recompose';

import { loadItems, loginAPI } from './LoginState';

import CalendarScreen from './LoginView';

export default compose(
  connect(
    state => ({
      items: state.calendar.items,
      isSuccess: state.login.isSuccess
    }),
    {
      loadItems,
      loginAPI
    },
  ),
)(CalendarScreen);

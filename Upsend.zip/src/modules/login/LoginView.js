/* eslint-disable class-methods-use-this */
import React from 'react';
import { StyleSheet, View, Text, Image, ImageBackground } from 'react-native';
import { Agenda } from 'react-native-calendars';
import { Button, TextInput } from '../../components';

import { colors, fonts } from '../../styles';

class LoginScreen extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      username: '',
      password: '',
    };
  }

  go = () => {
    const reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (reg.test(this.state.email) === true) {
      alert('valid');
    } else {
      alert();
    }
  };

  onLogin() {
    const { username, password } = this.state;
    const reqObj = {
      agent: {
        email: username,
        password: password,
      },
      email: username,
      password: password,
      grant_type: 'password',
    };
    // this.props.navigation.navigate("React Native Starter");
    this.props.loginAPI(reqObj, this.props.navigation);
    console.log('Login');
    // Alert.alert('Credentials', `${username} + ${password}`);
  }

  onSignup() {
    this.props.navigation.navigate('Register');
  }

  render() {
    let { items, isSuccess } = this.props;
    return (
      <ImageBackground
        source={require('../../../assets/images/background.png')}
        style={styles.container}
      >
        <Image
          source={require('../../../assets/images/login.png')}
          style={styles.nerdImage}
        />

        <View style={styles.textContainer}>
          <Text style={styles.availableText}>Please Login</Text>
        </View>
        <View style={styles.inputView}>
          <TextInput
            value={this.state.username}
            onChangeText={username => this.setState({ username })}
            placeholder="Email"
            style={styles.input}
          />
          <TextInput
            value={this.state.password}
            secureTextEntry
            onChangeText={password => this.setState({ password })}
            placeholder="Password"
            style={styles.input}
          />
          <Text style={styles.errorText}>
            { !isSuccess ? "" : 'User email and password is incorrect'}
          </Text>
        </View>
        <View />
        <View />
        <View style={styles.buttonsContainer}>
          <Button
            large
            bordered
            rounded
            style={styles.button}
            caption="Login"
            onPress={() => this.onLogin()}
          />

          <Button
            large
            secondary
            rounded
            style={[styles.button, styles.signupBtn]}
            caption="Sign Up"
            onPress={() => this.onSignup()}
          />
        </View>
      </ImageBackground>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    paddingHorizontal: 30,
    paddingVertical: 50,
    justifyContent: 'space-around',
  },
  nerdImage: {
    width: 80,
    height: 80,
  },
  availableText: {
    color: colors.white,
    fontFamily: fonts.primaryRegular,
    fontSize: 40,
    marginVertical: 3,
  },
  textContainer: {
    alignItems: 'center',
  },
  buttonsContainer: {
    alignItems: 'center',
    alignSelf: 'stretch',
  },
  button: {
    alignSelf: 'stretch',
    marginBottom: 20,
  },
  item: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: 'white',
    borderRadius: 5,
    padding: 10,
    marginRight: 10,
    marginTop: 10,
  },
  emptyDate: {
    height: 15,
    flex: 1,
    paddingTop: 30,
  },
  input: {
    width: '100%',
    marginTop: 30,
  },
  inputView: {
    width: '100%',
  },
  signupBtn: {
    width: '60%',
    alignSelf: 'center',
  },
  errorText: {
    color: colors.secondary,
    alignSelf: 'center',
    marginTop: 10,
    fontSize: 15
  }
});

export default LoginScreen;

import React, { useState } from 'react';
import { View } from 'react-native';

import Form from 'react-native-basic-form';
import * as api from '../../services/auth';
import { useAuth } from '../../providers/auth';

import CTA from '../../components/CTA';
import { Header, ErrorText } from '../../components/Shared';

export default function Login(props) {
  const { navigation } = props;
  const { navigate } = navigation;

  // 1 - DECLARE VARIABLES
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const { handleLogin } = useAuth();

  const fields = [
    { name: 'email', label: 'Email Address', required: true },
    { name: 'password', label: 'Password', required: true, secure: true },
  ];

  async function onSubmit(state) {
    // setLoading(true);

    try {
      const reqObj = {
        agent:{
          email: "testMobile@mail.com",
          password: "testMobile"
        },
        email: "testMobile@mail.com",
        password: "testMobile",
        grant_type: "password"
      }
      const response = await api.login(reqObj);
      await handleLogin(response);

      setLoading(false);

      // check if username is null
      const username = response.user.username !== null;
      if (username) navigate('App');
      else navigation.replace('Username');
    // eslint-disable-next-line no-shadow
    } catch (error) {
      setError(error.message);
      setLoading(false);
    }
  }

  const formProps = { title: 'Login', fields, onSubmit, loading };
  return (
    <View style={{ flex: 1, paddingHorizontal: 16, backgroundColor: '#fff' }}>
      <Header title="Login" />
      <View style={{ flex: 1 }}>
        <ErrorText error={error} />
        <Form {...formProps}>
          <CTA
            ctaText="Forgot Password?"
            onPress={() => navigation.navigate('ForgotPassword')}
            style={{ marginTop: 20 }}
          />

          <CTA
            title={"Don't have an account?"}
            ctaText="Register"
            onPress={() => navigation.replace('Register')}
            style={{ marginTop: 50 }}
          />
        </Form>
      </View>
    </View>
  );
}

Login.navigationOptions = ({}) => {
  return {
    title: ``,
  };
};

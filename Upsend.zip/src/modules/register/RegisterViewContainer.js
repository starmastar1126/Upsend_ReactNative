import { connect } from 'react-redux';
import { compose } from 'recompose';

import { loadItems, signupAPI } from './RegisterState';

import RegisterScreen from './RegisterView';

export default compose(
  connect(
    state => ({
      items: state.calendar.items,
    }),
    {
      loadItems,
      signupAPI
    },
  ),
)(RegisterScreen);

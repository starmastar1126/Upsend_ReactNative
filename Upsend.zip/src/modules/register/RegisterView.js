/* eslint-disable class-methods-use-this */
import React from 'react';
import {
  StyleSheet,
  View,
  Text,
  Image,
  ImageBackground,
} from 'react-native';
import { Button, TextInput } from '../../components';

import { colors, fonts } from '../../styles';

class RegisterScreen extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      firstName: '',
      lastName: '',
      email: '',
      password: '',
    };
  }

  // eslint-disable-next-line react/sort-comp
  go = () => {
    const reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    return reg.test(this.state.email);
  };

  onSignup() {
    const { firstName, lastName, email, password } = this.state;
    const reqObj = 
    {
      agent:{
        first_name: firstName,
        last_name: lastName,
        email,
        password
      }
    }
    this.props.signupAPI(reqObj, this.props.navigation);
  }

  render() {
    return (
      <ImageBackground
        source={require('../../../assets/images/background.png')}
        style={styles.container}
      >
        <Image
          source={require('../../../assets/images/signup.png')}
          style={styles.nerdImage}
        />

        <View style={styles.textContainer}>
          <Text style={styles.availableText}>Signup</Text>
        </View>
        <View style={styles.inputView}>
          <View style={styles.loginLayout}>
            <TextInput
              value={this.state.firstName}
              onChangeText={firstName => this.setState({ firstName })}
              placeholder="First Name"
              style={styles.nameInput}
            />
            <TextInput
              value={this.state.lastName}
              onChangeText={lastName => this.setState({ lastName })}
              placeholder="Last Name"
              style={[styles.nameInput, styles.customLeft]}
            />
          </View>
          <TextInput
            value={this.state.email}
            onChangeText={email => this.setState({ email })}
            placeholder="Email"
            style={styles.input}
          />
          <TextInput
            value={this.state.password}
            secureTextEntry 
            onChangeText={password => this.setState({ password })}
            placeholder="Password"
            style={styles.input}
          />
        </View>
        <View />
        <View />
        <View style={styles.buttonsContainer}>
          <Button
            large
            bordered
            rounded
            style={styles.button}
            caption="Signup"
            onPress={() => this.onSignup()}
          />
        </View>
        <View style={styles.loginLayout}>
          <Text style={styles.loginGuideText}>Already have a account? </Text>
          <Text
            secondary
            style={styles.loginText}
            onPress={() => this.props.navigation.navigate('Login')}
          >
            Login
          </Text>
        </View>
      </ImageBackground>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    paddingHorizontal: 30,
    paddingVertical: 50,
    justifyContent: 'space-around',
  },
  nerdImage: {
    width: 80,
    height: 80,
  },
  availableText: {
    color: colors.white,
    fontFamily: fonts.primaryRegular,
    fontSize: 40,
    marginVertical: 3,
  },
  loginGuideText: {
    color: colors.white,
    fontFamily: fonts.primaryRegular,
    fontSize: 20,
  },
  loginText: {
    color: colors.secondary,
    fontFamily: fonts.primaryBold,
    fontSize: 22,
  },
  textContainer: {
    alignItems: 'center',
  },
  buttonsContainer: {
    alignItems: 'center',
    alignSelf: 'stretch',
  },
  button: {
    alignSelf: 'stretch',
    marginBottom: 20,
  },
  item: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: 'white',
    borderRadius: 5,
    padding: 10,
    marginRight: 10,
    marginTop: 10,
  },
  emptyDate: {
    height: 15,
    flex: 1,
    paddingTop: 30,
  },
  input: {
    width: '100%',
    marginTop: 30,
  },
  inputView: {
    width: '100%',
  },
  signupBtn: {
    width: '60%',
    alignSelf: 'center',
  },
  loginLayout: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    width: '100%',
    alignContent: 'center'
  },
  nameInput: {
    width: 150,
    marginTop: 10,
  },
  customLeft: {
    marginLeft: 10,
  },
});

export default RegisterScreen;

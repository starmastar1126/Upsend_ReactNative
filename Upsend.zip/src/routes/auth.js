import { createStackNavigator } from '@react-navigation/stack';

// IMPORT SCENES
import RegisterScreen from '../modules/auth/Register';
import LoginScreen from '../modules/auth/Login';
import UsernameScreen from '../modules/auth/UserName';
// import ForgotPasswordScreen from '../auth/ForgotPassword';

// import { headerStyle, headerTitleStyle } from '../theme';

// Create Routes
const Stack = createStackNavigator();

export default function AuthStack() {
  return (
    <Stack.Navigator initialRouteName="Login">
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Register" component={LoginScreen} />
      <Stack.Screen name="Username" component={UsernameScreen} />
    </Stack.Navigator>
  );
}

// ({
//   Register: RegisterScreen,
//   Login: LoginScreen,
//   Username: UsernameScreen,
//   // ForgotPassword: ForgotPasswordScreen,
// });
// ,
// {
//   initialRouteName: 'Login',
//   // defaultNavigationOptions: () => ({ headerStyle, headerTitleStyle }),
// },

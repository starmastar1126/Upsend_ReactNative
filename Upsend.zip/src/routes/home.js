import { createStackNavigator } from '@react-navigation/stack';

// IMPORT SCENES
import HomeScreen from '../modules/home/Home';
// import UpdateProfileScreen from '../scenes/home/UpdateProfile';

// import { headerStyle, headerTitleStyle } from '../theme';

const Stack = createStackNavigator();
export default function HomeStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Home" component={HomeScreen} />
    </Stack.Navigator>
  );
}

// (
//   {
//     Home: HomeScreen,
//     // UpdateProfile: UpdateProfileScreen,
//   }
// //   ,
// //   {
// //     initialRouteName: 'Home',
// //     // defaultNavigationOptions: () => ({ headerStyle, headerTitleStyle }),
// //   },
// );

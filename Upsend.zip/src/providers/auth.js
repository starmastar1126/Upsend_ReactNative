import React, {useMemo, useReducer, useContext} from 'react';
import AsyncStorage from "@react-native-community/async-storage";
import axios from "axios";

// IMPORT REDUCER, INITIAL STATE AND ACTION TYPES
import reducer, {initialState, LOGGED_IN, LOGGED_OUT} from "../reducer";

// CONFIG KEYS [Storage Keys]===================================
export const TOKEN_KEY = 'token';
export const USER_KEY = 'user';
export const keys = [TOKEN_KEY, USER_KEY];

// CONTEXT ===================================
const AuthContext = React.createContext();

function AuthProvider(props) {
    const [state, dispatch] = useReducer(reducer, initialState || {});

    // Get Auth state
    const getAuthState = async () => {
        try {
            // GET TOKEN && USER
            const token = await AsyncStorage.getItem(TOKEN_KEY);
            let user = await AsyncStorageAnd.getItem(USER_KEY);
            user = JSON.parse(user);
            
            if (token !== null && user!== null) await handleLogin({token, user});
            else await handleLogout();

            return {token, user};
        } catch (error) {
            throw new Error(error)
        }
    };

    // access_token: "0lnH5qNNoFB41HHtn91-as2a_BuRxoggRvBYfn403nQ"
    // created_at: 1589200065
    // expires_at: 1589207265
    // refresh_token: "sT1-1YERKKhxSbrdb-rw8W0y0ENBWCxdy41rGV-hFqo"
    // scope: "read"
    // token_type: "Bearer"

    // Handle Login
    const handleLogin = async (data) => {
        try{
            // STORE DATA
            const {access_token, refresh_token} = data;
            const data_ = [[ACCESS_TOKEN, access_token], [REFRESH_TOKEN, refresh_token]];
            await AsyncStorage.multiSet(data_);

            // AXIOS AUTHORIZATION HEADER
            axios.defaults.headers.common["Authorization"] = `Bearer ${access_token}`;

            // DISPATCH TO REDUCER
            dispatch({type: LOGGED_IN, user:data.user});
        }catch (error) {
            throw new Error(error);
        }
    };

    // Handle Logout
    const handleLogout = async () => {
        try{

            // REMOVE DATA
            await AsyncStorage.multiRemove(keys);

            // AXIOS AUTHORIZATION HEADER
            delete axios.defaults.headers.common["Authorization"];

            // DISPATCH TO REDUCER
            dispatch({type: LOGGED_OUT});
        }catch (error) {
            throw new Error(error);
        }
    };

    // UPDATE USER LOCAL STORAGE DATA AND DISPATCH TO REDUCER
    const updateUser = async (user) => {
        try {
            await AsyncStorage.setItem(USER_KEY, JSON.stringify(user));
            dispatch({type: LOGGED_IN, user}); // DISPATCH TO REDUCER
        } catch (error) {
            throw new Error(error);
        }
    };

    const value = useMemo(() => {
        return {state, getAuthState, handleLogin, handleLogout, updateUser};
    }, [state]);

    return (
        <AuthContext.Provider value={value}>
            {props.children}
        </AuthContext.Provider>
    );
}

const useAuth = () => useContext(AuthContext);
export { AuthContext, useAuth }
export default AuthProvider;
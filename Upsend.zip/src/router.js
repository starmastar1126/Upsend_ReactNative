import React from 'react';

import { createAppContainer, createSwitchNavigator, NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

// IMPORT ROUTES
import AuthStack from './routes/auth';
import HomeStack from './routes/home';

import AuthLoading from './modules/auth/authLoading';
import AuthProvider from './providers/auth';

import AppView from './modules/AppViewContainer';

// APP ROUTES STACK
// const AppStack = createSwitchNavigator(
//   {
//     Loading: AuthLoading,
//     Auth: AuthStack,
//     App: HomeStack,
//   },
//   { initialRouteName: 'Loading' },
// );

// const Navigator = createAppContainer(AppStack);

const Stack = createStackNavigator();

export default function Router() {
  return (
    <AuthProvider>
      {/* <Navigator /> */}
      <NavigationContainer>
        <Stack.Navigator>
          <Stack.Screen name="Loading" component={AuthLoading} />
          <Stack.Screen name="Auth" component={AuthStack} />
          <Stack.Screen name="App" component={AppView} />
        </Stack.Navigator>
      </NavigationContainer>
    </AuthProvider>
  );
}
